from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import argparse
parser = argparse.ArgumentParser(description="Run the local student app")
parser.add_argument("--port", type=int, default=8000)
args = parser.parse_args()
try:
    server = ThreadingHTTPServer(("127.0.0.1", args.port), partial(SimpleHTTPRequestHandler, directory=str(Path(__file__).resolve().parent / "app")))
except OSError as error:
    parser.exit(1, f"Could not start: {error}\nTry --port 8001.\n")
print(f"Open http://127.0.0.1:{server.server_port} — Ctrl+C to stop", flush=True)
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
